import VueRouter from 'vue-router' // 供创建路由对象使用
// import Dashboard from './components/Dashboard.vue' // TODO delete
import AxiosDemo from './components/demo/AxiosDemo.vue'
import Form from './components/demo/Form.vue'
import FormInputVal from './components/demo/FormInputVal.vue'
import MachineLearning from './components/modules/expertanalysis/MachineLearning.vue'
import Login from './components/Login.vue' // 登录页
import Home from './components/modules/Home.vue' // 首页
import MainContainer from './components/partials/MainContainer.vue' // 功能页容器
import HomeContainer from './components/partials/HomeContainer.vue' // 主页容器
import LinearAnalysis from './components/modules/expertanalysis/LinearAnalysis.vue'
import IntelligentAnalysis from './components/modules/expertanalysis/IntelligentAnalysis.vue' // 智能分析
import BenchmarkingAnalysis from './components/modules/expertanalysis/BenchmarkingAnalysis.vue' // 对标分析
import IndexManagement from './components/modules/indexmanagement/IndexManagement.vue'
import AnalysisData from './components/modules/expertanalysis/AnalysisData.vue'
import ProgramManagement from './components/modules/expertanalysis/ProgramManagement.vue'

const routes = [
  {
    path: '',
    name: 'login',
    component: Login,
    alias: '/login',
    meta: { requiresAuth: true },
    beforeEnter: (to, from, next) => {
      next()
    },
    activate: function () {
      this.$nextTick(function () {
        // => 'DOM loaded and ready'
        alert('test')
      })
    }
  },
  {
    path: '/home-container',
    component: HomeContainer,
    meta: { requiresAuth: true },
    beforeEnter: (to, from, next) => {
      document.body.className += 'skin-Light sidebar-mini'
      next()
    },
    activate: function () {
      this.$nextTick(function () {
        // => 'DOM loaded and ready'
        alert('test')
      })
    },
    children: [
      {
        path: '',
        name: 'home',
        component: Home
      },
      {
        path: '/main-container',
        name: 'main-container',
        component: MainContainer,
        children: [
          {
            path: '/axios-demo',
            name: 'axios-demo',
            component: AxiosDemo
          },
          {
            path: '/form-input-val',
            name: 'form-input-val',
            component: FormInputVal
          },
          {
            path: '/form',
            name: 'form',
            component: Form
          },
          {
            path: '/linear-analysis',
            name: 'linear-analysis',
            component: LinearAnalysis
          },
          {
            path: '/intelligent-analysis',
            name: 'intelligent-analysis',
            component: IntelligentAnalysis
          },
          {
            path: '/benchmarking-analysis',
            name: 'benchmarking-analysis',
            component: BenchmarkingAnalysis
          },
          {
            path: '/analysis-data',
            name: 'analysis-data',
            component: AnalysisData
          },
          {
            path: '/program-management',
            name: 'program-management',
            component: ProgramManagement
          },
          {
            path: '/machine-learning',
            name: 'machine-learning',
            component: MachineLearning
          },
          {
            path: '/analysis-obj',
            name: 'analysis-obj',
            component: resolve => require.ensure([], () => resolve(require('./components/modules/expertanalysis/AnalysisObj.vue')), 'analysis-obj-view')
          },
          {
            path: '/object-base',
            name: 'object-base',
            component: resolve => require.ensure([], () => resolve(require('./components/modules/expertanalysis/ObjectBase.vue')), 'object-base-view')
          },
          {
            path: '/index-management',
            name: 'index-management',
            component: IndexManagement
          },
          {
            path: '/index-type-management',
            name: 'index-type-management',
            component: resolve => require.ensure([], () => resolve(require('./components/modules/indexmanagement/IndexTypeManagement.vue')), 'index-type-view')
          },
          {
            path: '/object-type-management',
            name: 'object-type-management',
            component: resolve => require.ensure([], () => resolve(require('./components/modules/expertanalysis/ObjectTypeManagement.vue')), 'object-type-management-view')
          },
          {
            path: '/object-type-base',
            name: 'object-type-base',
            component: resolve => require.ensure([], () => resolve(require('./components/modules/expertanalysis/ObjectTypeBase.vue')), 'object-type-base-view')
          },
          {
            // 功能列表展示页
            path: '/function-list',
            name: 'function-list',
            component: resolve => require.ensure([], () => resolve(require('./components/modules/system/functions/FunctionList.vue')), 'function-list-view')
          },
          {
            // 用户列表展示页
            path: '/user-list',
            name: 'user-list',
            component: resolve => require.ensure([], () => resolve(require('./components/modules/system/user/UserList.vue')), 'user-list-view')
          },
          {
            // 用户基本信息页
            path: '/user-base',
            name: 'user-base',
            component: resolve => require.ensure([], () => resolve(require('./components/modules/system/user/UserBase.vue')), 'user-base-view')
          },
          {
            // 角色列表展示页
            path: '/role-list',
            name: 'role-list',
            component: resolve => require.ensure([], () => resolve(require('./components/modules/system/role/RoleList.vue')), 'role-list-view')
          },
          {
            // 角色基本信息页
            path: '/role-base',
            name: 'role-base',
            component: resolve => require.ensure([], () => resolve(require('./components/modules/system/role/RoleBase.vue')), 'role-base-view')
          }
        ]
      }
    ]
  }
]

// 由main.js移至此处
const router = new VueRouter({
  routes: routes,
  mode: 'history',
  linkActiveClass: 'open active',
  scrollBehavior: function (to, from, savedPosition) {
    return savedPosition || { x: 0, y: 0 }
  }
})
export default router
