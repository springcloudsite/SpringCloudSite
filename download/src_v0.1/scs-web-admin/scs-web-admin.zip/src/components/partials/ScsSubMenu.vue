<template v-if="!menu.hidden">
  <el-menu-item v-if="menu.leaf" :index="menu.uuid">
    <i :class="menu.iconCls"></i>
    <span slot="title">{{menu.name}}</span>
  </el-menu-item>
  <el-submenu v-else :index="menu.uuid">
    <template slot="title">
      <i :class="menu.iconCls"></i>
      <span slot="title">{{menu.name}}</span>
    </template>
    <template v-if="menu.children.length>0" v-for="submenu in menu.children">
      <scs-sub-menu :key="submenu.id" :menu="submenu"></scs-sub-menu>
    </template>
  </el-submenu>
</template>

<script>
export default {
  name: 'scs-sub-menu',
  data () {
    let data = {
      subIndex: new Date().getTime()
    }
    return data
  },
  props: ['menu'],
  mounted () {},
  methods: {}
}
</script>