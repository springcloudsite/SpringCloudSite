<template>
  <footer class="main-footer">
    <div class="footerBox">
      <div class="content">
        <h4>售前咨询热线</h4>
        <ul>
          <li></li>
          <li></li>
        </ul>
        <div class="pull-right hidden-xs">
          <b>Version</b> 1.1
        </div>
        SpringCloudSite<a href="#"><strong>京备号</strong></a>
      </div>
    </div>
  </footer>
</template>

<script>
  export default {
    name: 'DashboardFooter'
  }
</script>

<style scoped lang="scss">
.footerBox{
  background-color: #373d41;
  padding: 30px 0;
  color: #d7d8d9;
}
</style>
