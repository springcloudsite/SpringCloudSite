<template>
    <transition name="el-zoom-in-center">
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <section class="content-header">
                <h1>axios测试<small> <i class="ti-heart"></i><i class="ti-export"></i><i class="ti-printer"></i></small></h1>
                <ol class="breadcrumb">
                    <li>
                        <router-link to="/"> <i class="ti-home"></i></router-link>
                    </li>
                    <li><a href="#">axios测试 </a></li>
                    <li class="active">Input</li>
                </ol>
            </section>
            <!-- Main content -->
            <section class="content">
                <!-- Default box -->
                <div class="box">
                   
                    <div class="box-body">
                       
                        <h4>axios测试</h4>

                         <el-input type="textarea" :rows="2" placeholder="Please input" v-model="geturl"></el-input>
                         <el-button type="success" @click="clickgetTest()">get</el-button>
                         <el-button type="success" @click="clickpostTest()">post</el-button>
                         <el-button type="success" @click="clickputTest()">put</el-button>
                         <el-button type="success" @click="clickpatchTest()">patch</el-button>
                         <el-button type="success" @click="clickdeleteTest()">delete</el-button>
                        <hr> 
                         <div class="box-header">
                  
                     {{ messagevalue }}
 
                    </div>
                        </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->
           
            </section>
            <!-- /.content -->
 
          <Spin size="large" fix v-if="spinShow"></Spin>
        </div>
    </transition>
</template>
<script>
  export default {
    props: ['todo'],
    data: function () {
      return {
        spinShow: false,
        isEditing: false,
        geturl: 'https://www.easy-mock.com/mock/5ac363becbe63067f2d6ca46/example/dicttest#!method=get',
        messagevalue: 'not found'
      }
    },
    methods: {
      clickgetTest: function () {
        let that = this
        this.spinShow = true
        this.$axios({
          method: 'get',
          url: this.geturl,
          params: {
            'page': '2',
            'limit': '3',
            'sort': 'id.desc,name.asc'
          }
        }).then(function (response) {
          that.spinShow = false
          this.messagevalue = response.data
          console.log(this.messagevalue)
        }.bind(this)).catch(function (error) {
          that.spinShow = false
          console.log(error)
        })
      },
      clickpostTest: function () {
        this.$axios({
          method: 'post',
          url: this.geturl,
          data: {
            'id': '1',
            'name': '唐河县上城10MW分散式风电项目'
          }
        }).then(function (response) {
          this.messagevalue = response.data
          console.log(this.messagevalue)
        }.bind(this)).catch(function (error) {
          console.log(error)
        })
      },
      clickputTest: function () {
        this.$axios({
          method: 'put',
          url: this.geturl,
          data: {
            'id': 1,
            'name': '唐河县上城10MW分散式风电项目'
          }
        }).then(function (response) {
          this.messagevalue = response.data
          console.log(this.messagevalue)
        }.bind(this)).catch(function (error) {
          console.log(error)
        })
      },
      clickpatchTest: function () {
        this.$axios({
          method: 'patch',
          url: this.geturl,
          data: {
            'id': 1,
            'name': '唐河县上城10MW分散式风电项目'
          }
        }).then(function (response) {
          this.messagevalue = response.data
          console.log(this.messagevalue)
        }.bind(this)).catch(function (error) {
          console.log(error)
        })
      },
      clickdeleteTest: function () {
        this.$axios({
          method: 'delete',
          url: this.geturl,
          data: {
            'id': '1'
          }
        }).then(function (response) {
          this.messagevalue = response.data
          console.log(this.messagevalue)
        }.bind(this)).catch(function (error) {
          console.log(error)
        })
      },
      change (e) {
        if (e.length === 1) {
          // this.userModifySet(e['0'])
        }
        this.setGroupId(e)
      },
      dblclick (e) {
        // this.userModifySet(e)
        // this.modifyModal = true
        this.data1.sort()
      },
      pageSearch (e) {
        this.pageInfo.page = e - 1
      }
    }
  }
</script>