<style>
.demo-upload-list {
  display: inline-block;
  width: 60px;
  height: 60px;
  text-align: center;
  line-height: 60px;
  border: 1px solid transparent;
  border-radius: 4px;
  overflow: hidden;
  background: #fff;
  position: relative;
  box-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);
  margin-right: 4px;
}
.demo-upload-list img {
  width: 100%;
  height: 100%;
}
.demo-upload-list-cover {
  display: none;
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  background: rgba(0, 0, 0, 0.6);
}
.demo-upload-list:hover .demo-upload-list-cover {
  display: block;
}
.demo-upload-list-cover i {
  color: #fff;
  font-size: 20px;
  cursor: pointer;
  margin: 0 2px;
}
</style>
<template>

  <transition name="el-zoom-in-center">

    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <h1>Forms Input
          <small>
            <i class="ti-heart"></i>
            <i class="ti-export"></i>
            <i class="ti-printer"></i>
          </small>
        </h1>
        <ol class="breadcrumb">
          <li>
            <router-link to="/">
              <i class="ti-home"></i>
            </router-link>
          </li>
          <li>
            <a href="#">Forms </a>
          </li>
          <li class="active">Input</li>
        </ol>
      </section>

      <!-- Main content -->
      <section class="content">
        <!-- Default box -->
        <div class="box">
          <div class="box-header">
            <div class="box-tools pull-right">
              <button type="button" data-widget="collapse" data-toggle="tooltip" title="Collapse" class="btn btn-box-tool">
                <i class="ti-minus"></i>
              </button>
              <button type="button" data-widget="remove" data-toggle="tooltip" title="Remove" class="btn btn-box-tool">
                <i class="ti-close"></i>
              </button>
              <button type="button" data-widget="btn btn-success" data-toggle="tooltip" title="切换语言" class="btn btn-box-tool" @click="changeLocale">中文/EN</button>

            </div>
          </div>

          <div class="box-body">
            <el-form ref="userNew" :model="userNew" :loading="loading" :rules="ruleNew" label-width="80px">

              <img :src="itemurl">
              <div class="demo-upload-list-cover">
                <i type="el-icon-view" @click.native="handleView('test1')"></i>
              </div>

              <el-upload ref="upload" :show-upload-list="false" :default-file-list="defaultList" :on-success="handleSuccess" :on-progress="onprogress" :format="['jpg','jpeg','png']" :max-size="2048" multiple type="drag" :action="uploadurl" style="display: inline-block;width:58px;">
                <div style="width: 58px;height:58px;line-height: 58px;">
                  <i class="el-icon-picture-outline"></i>
                </div>
              </el-upload>
              <el-form-item :label="$t('FormInputVal.loginname')" prop="loginName">
                <el-input placeholder="Please input" v-model="userNew.loginName"></el-input>
              </el-form-item>
              <el-form-item :label="$t('FormInputVal.username')" prop="name">
                <el-input v-model="userNew.name" style="width: 404px" />
              </el-form-item>
              <el-form-item :label="$t('FormInputVal.password')" prop="password">
                <el-input v-model="userNew.password" type="password" style="width: 404px" />
              </el-form-item>
              <el-form-item :label="$t('FormInputVal.confirmpass')" prop="passwordAgain">
                <el-input v-model="userNew.passwordAgain" type="password" style="width: 404px" />
              </el-form-item>
              <el-form-item :label="$t('FormInputVal.checks')" prop="checklist">
                <tgcw-checkboxlist datatype="required_major" default="1,2" v-on:ref="refvalues"> </tgcw-checkboxlist>
              </el-form-item>
              <el-form-item :label="$t('FormInputVal.email')" prop="email">
                <el-input v-model="userNew.email" style="width: 404px" />
              </el-form-item>

              <el-upload :show-upload-list="true" :before-upload="renameUpload" :on-remove="onremove" :on-success="handleSuccess" :default-file-list="defaultList" action="http://10.11.60.52:8082/projectfile">
                <el-button type="ghost" icon="ios-cloud-upload-outline">Upload files</el-button>
              </el-upload>

              <li v-for="(item,index) in updatelist">
                {{index}}:{{ item.name }}
              </li>

              切换显示状态：
              <el-switch @on-change="spinShow = !spinShow"></el-switch>
            </el-form>
            <hr>
            <el-button type="success" @click="newOk('userNew')">提交</el-button>
            <el-button type="success" @click="loading()">加载中</el-button>
            <el-button type="success" @click="modal1 = true">模态加载</el-button>
            <el-button type="success" @click="testexception()">测试异常</el-button>
          </div>
          <!-- /.box-body -->
        </div>
        <!-- /.box -->

      </section>
      <!-- /.content -->
      <Spin size="large" fix v-if="spinShow"></Spin>
    </div>

  </transition>

</template>
<script>
import TgcwCheckboxlist from '../commons/TgcwCheckboxlist.vue'
export default {
  name: 'FormInput',
  data () {
    const usermatch = (rule, value, callback) => {
      this.spinShow = true
      let that = this
      this.$axios({
        method: 'get',
        url:
          'http://10.11.60.2:8081/tgcw-service-system/sysdictionary/type/' +
          'required_major'
      })
        .then(function (response) {
          var matchvalue = response.data
          that.spinShow = false
          console.log('matchvalue:')
          console.log(matchvalue)
        })
        .catch(function (error) {
          that.spinShow = false
          console.log(error)
        })

      if (!/^[a-zA-Z\d]+$/.test(value)) {
        return callback(new Error('必须为字母或数字'))
      } else {
        callback()
      }
    }
    const validatTestePassCheck = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请输入确认密码'))
      } else if (value !== this.userNew.password) {
        callback(new Error('请输入一样的密码!'))
      } else {
        callback()
      }
    }
    return {
      /* 文件上传列表 */
      uploadurl: '',
      loadingstatus: 'finished',
      itemshowProgress: false,
      itemstatus: 'finished',
      renamefilename: '',
      itemurl: '',
      itempercentage: 100,
      defaultList: [],
      updatelist: [],
      spinShow: false,
      resurl: '',
      /* 新建实体 */
      userNew: {
        id: null,
        name: null,
        loginName: null,
        password: null,
        passwordAgain: null,
        checklist: null,
        email: null
      },
      fileobject: {
        name: '',
        url: ''
      },
      /* 新建验证 */
      ruleNew: {
        name: [{ validator: usermatch, required: true, trigger: 'blur' }],
        loginName: [
          {
            type: 'string',
            required: true,
            message: '输入登录名',
            trigger: 'blur'
          },
          {
            validator (rule, value, callback) {
              if (!Number.isInteger(+value)) {
                callback(new Error('请输入数字'))
              } else {
                callback()
              }
            },
            trigger: 'blur'
          }
        ],
        password: [
          {
            type: 'string',
            required: true,
            message: '输入密码',
            trigger: 'blur'
          }
        ],
        passwordAgain: [
          { validator: validatTestePassCheck, required: true, trigger: 'blur' }
        ],
        checklist: [{ required: true, type: 'array', message: '请全部选择' }],
        email: [
          { required: true, message: '输入邮箱', trigger: 'blur' },
          { type: 'email', message: '输入正确的邮箱格式', trigger: 'blur' }
        ]
      },
      input: '',
      num1: 1,
      recivevalues: []
    }
  },
  components: {
    TgcwCheckboxlist
  },
  mounted () {
    this.uploadurl = this.global.serverPath + this.global.url.fileupload
  },
  methods: {
    changeLocale () {
      this.$confirm(this.$t('lang.toggle'), this.$t('lang.tips'), {
        confirmButtonText: this.$t('lang.ok'),
        cancelButtonText: this.$t('lang.cancel'),
        type: 'warning'
      })
        .then(() => {
          let locale = this.$i18n.locale
          locale === 'zh'
            ? (this.$i18n.locale = 'en')
            : (this.$i18n.locale = 'zh')
        })
        .catch(() => {
          this.$message({
            type: 'info'
          })
        })
    },
    testexception () {
      alert(this.JavaException('exception.userrepeat'))
    },
    refvalues: function (msg) {
      console.log('获取的消息值')
      this.recivevalues = msg
      console.log(this.recivevalues)
    },
    renameUpload (file) {
      this.renamefilename = 'defaultfile'
      this.$Modal.confirm({
        onOk: () => {
          var fileobj = { url: this.resurl, name: this.renamefilename }
          this.updatelist.push(fileobj)
          this.defaultList = this.updatelist
          console.log(this.updatelist)
        },
        render: h => {
          return h('el-input', {
            props: {
              value: this.value,
              autofocus: true,
              placeholder: '请输入你需要修改的文件么名'
            },
            on: {
              input: val => {
                this.renamefilename = val
              }
            }
          })
        }
      })
      return true
    },
    onremove (file) {
      console.log(file.name)
      this.updatelist = this.defaultList
      // var objarr = {url: 'test', name: 'this.renamefilename'}
      // this.$set(this.updatelist, 0, objarr)

      var matchi = -1
      for (var i = 0; i <= this.updatelist.length - 1; i++) {
        if (file.name === this.updatelist[i].name) {
          matchi = i
          console.log(this.updatelist[i].name + '->')
          break
        }
      }
      if (matchi !== -1) {
        console.log(i)
        this.updatelist.splice(i, 1)
      }
    },
    onprogress (event, file) {
      console.log('百分比:')
      itempercentage = event.percent
      itemstatus = 'loading'
    },
    handleSuccess (res, file) {
      this.itemurl = this.global.serverPath + this.global.url.fileload + res
      this.itemstatus = 'finished'

      this.resurl = res
    },
    loading: function () {
      alert('loading')
      console.log('文件被命名为：' + this.renamefilename)
      console.log(this.updatelist)

      this.spinShow = true
      const msg = this.$Message.loading({
        content: 'Loading...',
        duration: 0
      })
      setTimeout(msg, 3000)
      this.spinShow = false
    },
    /* 最后的认证 */
    newOk (userNew) {
      this.$refs[userNew].validate(valid => {
        if (valid) {
          if (this.userNew.password === this.userNew.passwordAgain) {
            this.$Message.info('新建成功')
          } else {
            this.$Message.error('两次输入的密码不相同！')
          }

          console.log('还是要验证一下是不是全部数据')
          console.log(this.recivevalues)
        } else {
          this.$Message.error('表单验证失败!')
        }
      })
    }
  }
}
</script>