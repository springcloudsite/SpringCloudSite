<template>
  <transition>
    <div>
      <scs-table :table-option="tableOption"></scs-table>
    </div>
  </transition>
</template>
<script>
import ScsTable from '../../../commons/ScsTable.vue'
export default {
  name: 'button-list',
  components: {
    'scs-table': ScsTable
  },
  props: ['functionId'],
  data () {
    let _that = this
    let data = {
      tableOption: {
        showNum: true,
        columns: [
          {
            prop: 'functionName',
            label: '按钮名称'
          },
          {
            prop: 'functionCode',
            label: '按钮编码'
          },
          {
            prop: 'functionDescription',
            label: '描述信息'
          },
          {
            prop: 'isDisable',
            label: '是否显示',
            renderCell: function (h, scope) {
              let row = scope.row
              return h('el-switch', {
                attrs: {
                  value: row.isDisable
                },
                props: {
                  'active-value': '0',
                  'inactive-value': '1'
                },
                on: {
                  input: value => {
                    row.isDisable = value
                    _that.modifyButtonDisable(row.id, value)
                  }
                }
              })
            }
          },
          {
            prop: 'action',
            label: '操作',
            renderCell: function (h, scope) {
              let row = scope.row
              return h('div', [
                h(
                  'el-button',
                  {
                    attrs: {
                      value: row.ifShow === '1'
                    },
                    props: {
                      size: 'mini',
                      type: 'primary'
                    },
                    on: {
                      click: () => {
                        _that.loadModifyPage(row.id)
                      }
                    }
                  },
                  '编辑'
                ),
                h(
                  'el-button',
                  {
                    attrs: {
                      value: row.ifShow === '1'
                    },
                    props: {
                      size: 'mini',
                      type: 'danger'
                    },
                    on: {
                      click: () => {
                        _that.removeFunctionInfo(row.id)
                      }
                    }
                  },
                  '删除'
                )
              ])
            }
          }
        ],
        datas: []
      }
    }
    return data
  },
  watch: {
    // functionId (cur, old) {
    //   this.initButtonData()
    // }
  },
  mounted () {
    this.initPageData()
  },
  methods: {
    initPageData () {
      this.initButtonData()
    },
    initButtonData (ftnId) {
      // 初始化按钮列表数据
      let _ftnId = ftnId || this.functionId
      if (_ftnId) {
        this.$axios({
          method: 'GET',
          url:
            this.global.serverPathUser +
            this.global.url.functions.getAllFunctionByTypeAndParentId,
          urlParams: {
            functionType: '2',
            parentId: _ftnId
          }
        })
          .then(
            function (response) {
              let _data = response.data
              this.tableOption.datas = _data
            }.bind(this)
          )
          .catch(function (error) {
            console.log(error)
          })
      }
    },
    modifyButtonDisable (ftnId, isDisable) {
      // 修改数据
      this.$axios({
        method: 'PATCH',
        url:
          this.global.serverPathUser + this.global.url.functions.modifyFunction,
        data: {
          id: ftnId,
          isDisable: isDisable
        }
      })
        .then(
          function (response) {
            this.initButtonData()
          }.bind(this)
        )
        .catch(
          function (error) {
            console.log(error)
            this.$message({
              message: this.$t('commons.messages.failedAction'),
              type: 'error'
            })
          }.bind(this)
        )
    },
    loadModifyPage (ftnId) {
      this.$message({
        message: this.$t('commons.messages.TODO'),
        type: 'warning'
      })
    },
    removeFunctionInfo (ftnId) {
      // 删除按钮数据
      this.$confirm(
        this.$t('commons.messages.deleteConfirm'),
        this.$t('commons.titles.info'),
        {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }
      )
        .then(() => {
          this.$axios({
            method: 'DELETE',
            url:
              this.global.serverPathUser +
              this.global.url.functions.deleteFunction,
            urlParams: {
              id: ftnId
            }
          })
            .then(
              function (response) {
                this.$message({
                  message: this.$t('commons.messages.deleteSuccess'),
                  type: 'success'
                })
                this.initButtonData()
              }.bind(this)
            )
            .catch(
              function (error) {
                console.log(error)
                this.$message({
                  message: this.$t('commons.messages.failedAction'),
                  type: 'error'
                })
              }.bind(this)
            )
        })
        .catch(() => {
          console.log('cancel delete')
        })
    }
  }
}
</script>
<style scoped>
</style>

