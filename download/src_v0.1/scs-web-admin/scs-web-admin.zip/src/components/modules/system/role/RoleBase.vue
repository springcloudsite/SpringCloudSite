<template>
  <transition>
    <div>
      <el-tabs :value="tabValue" type="card" @tab-click="tabClick">
        <el-tab-pane name="baseInfo" label="基本信息">
          <el-form :model="formRole" :rules="rulesRole" ref="formRole" label-width="150px">
            <el-form-item label="角色编码" prop="roleCode">
              <el-input v-model="formRole.roleCode" placeholder="请输入角色编码"></el-input>
            </el-form-item>
            <el-form-item label="角色名称" prop="roleName">
              <el-input v-model="formRole.roleName" placeholder="请输入角色名称"></el-input>
            </el-form-item>
            <el-form-item label="详细描述" prop="roleDescription">
              <el-input v-model="formRole.roleDescription" placeholder="请输入详细描述" type="textarea"></el-input>
            </el-form-item>
            <el-form-item label="是否可用">
              <el-switch v-model="formRole.isDisable" active-value='0' inactive-value='1' active-text="启用" inactive-text="禁用"></el-switch>
            </el-form-item>
            <el-form-item label="是否删除">
              <el-switch v-model="formRole.isDelete" active-value='0' inactive-value='1' active-text="使用" inactive-text="删除"></el-switch>
            </el-form-item>
            <el-form-item>
              <el-button type="primary" @click="submitForm()">保存</el-button>
              <el-button @click="resetForm()">重置</el-button>
            </el-form-item>
          </el-form>
        </el-tab-pane>
        <el-tab-pane name="userRelationship" label="用户管理" :disabled="isTabDisableUser" lazy>
          <user-relationship :role-id="formRole.id"></user-relationship>
        </el-tab-pane>
        <el-tab-pane name="functionRelationship" label="资源管理" :disabled="isTabDisableFunction" lazy>
          <function-relationship :role-id="formRole.id"></function-relationship>
        </el-tab-pane>
      </el-tabs>
    </div>
  </transition>
</template>
<script>
import UserRelationship from './UserRelationship.vue'
import FunctionRelationship from './FunctionRelationship.vue'
export default {
  name: 'role-base',
  components: {
    'user-relationship': UserRelationship,
    'function-relationship': FunctionRelationship
  },
  data () {
    let _isNotChinese = this.customValidates('isNotChinese')
    let data = {
      isTabDisableUser: true,
      isTabDisableFunction: true,
      tabValue: 'baseInfo',
      formRole: {
        id: this.$route.query.id || '',
        roleCode: '',
        roleName: '',
        roleDescription: '',
        isDisable: '0',
        isDelete: '0'
      },
      rulesRole: {
        roleCode: [
          {
            required: true,
            message: '角色编码不能为空',
            trigger: ['blur', 'change']
          },
          {
            max: 20,
            message: '长度不能超过20字符',
            trigger: ['blur', 'change']
          },
          { validator: _isNotChinese, trigger: ['blur', 'change'] }
        ],
        roleName: [
          {
            required: true,
            message: '角色名称不能为空',
            trigger: ['blur', 'change']
          },
          {
            max: 20,
            message: '长度不能超过20字符',
            trigger: ['blur', 'change']
          }
        ],
        roleDescription: [
          {
            max: 200,
            message: '长度不能超过200字符',
            trigger: ['blur', 'change']
          }
        ]
      }
    }
    return data
  },
  watch: {
    // roleId (cur, old) {
    //   this.initRoleData()
    // }
  },
  mounted () {
    this.initPageData()
  },
  methods: {
    initPageData () {
      this.initRoleData()
    },
    initRoleData () {
      // 初始化数据
      let _roleId = this.formRole.id
      if (_roleId) {
        this.$axios({
          method: 'GET',
          url: this.global.serverPathUser + this.global.url.role.getRoleById,
          urlParams: {
            id: _roleId
          }
        })
          .then(
            function (response) {
              let _data = response.data
              this.formRole = _data
              this.controlTabsUser()
              this.isTabDisableFunction = false
            }.bind(this)
          )
          .catch(function (error) {
            console.log(error)
          })
      }
    },
    submitForm () {
      // 保存表单信息
      this.$refs.formRole.validate(valid => {
        if (valid) {
          let _data = {
            id: this.formRole.id,
            roleCode: this.formRole.roleCode,
            roleName: this.formRole.roleName,
            roleDescription: this.formRole.roleDescription,
            isDisable: this.formRole.isDisable,
            isDelete: this.formRole.isDelete
          }

          let _url = this.global.serverPathUser
          let _type = ''
          if (_data.id) {
            _url = _url + this.global.url.role.modifyRole
            _type = 'PATCH'
          } else {
            _url = _url + this.global.url.role.newRole
            _type = 'POST'
          }
          this.$axios({
            method: _type,
            url: _url,
            data: _data
          })
            .then(
              function (response) {
                this.$message({
                  message: this.$t('commons.messages.saveSuccess'),
                  type: 'success'
                })
                this.formRole.id = response.data.id
                this.controlTabsUser()
                this.isTabDisableFunction = false
              }.bind(this)
            )
            .catch(
              function (error) {
                console.log(error)
                this.showValidateMsg(this.$refs.formRole, error, this)
              }.bind(this)
            )
        } else {
          console.log('error submit!!')
          return false
        }
      })
    },
    controlTabsUser () {
      this.isTabDisableUser = this.formRole.roleCode === 'ANYONES'
    },
    resetForm () {
      // 重置表单
      this.$refs.formRole.resetFields()
    },
    tabClick (el) {
      // tab页签转换
      this.tabValue = el.name
    }
  }
}
</script>
<style scoped>
</style>

