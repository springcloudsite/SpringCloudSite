<template>
  <transition>
    <div>
      <el-row>
        <el-col :span="24">
          <el-input placeholder="请输入内容" v-model="searchUser.sValue">
            <el-select class="search-select" v-model="searchUser.sType" slot="prepend" placeholder="请选择">
              <el-option label="登录名称" value="1"></el-option>
              <el-option label="用户昵称" value="2"></el-option>
            </el-select>
            <el-button slot="append" icon="el-icon-search" @click="handleSearchUser"></el-button>
          </el-input>
        </el-col>
      </el-row>
      <scs-table ref="tableUser" :table-option="tableOption"></scs-table>
    </div>
  </transition>
</template>
<script>
import ScsTable from '../../../commons/ScsTable.vue'
export default {
  name: 'user-relationship',
  components: {
    'scs-table': ScsTable
  },
  props: ['roleId'],
  data () {
    let _that = this
    let data = {
      tableOption: {
        // showNum: true,
        columns: [
          {
            prop: 'loginName',
            label: '登录名称'
          },
          {
            prop: 'nickname',
            label: '用户昵称'
          },
          {
            prop: 'isDisable',
            label: '是否可用',
            renderCell: function (h, scope) {
              let row = scope.row
              return h('span', row.isDisable === '1' ? '禁用' : '启用')
            }
          },
          {
            prop: 'isRelationship',
            label: '关联关系',
            renderCell: function (h, scope) {
              let row = scope.row
              return h('el-switch', {
                attrs: {
                  value: !!row.roleId
                },
                on: {
                  input: value => {
                    _that.handleRelationship(value, row)
                  }
                }
              })
            }
          }
        ],
        datas: [],
        dataUrl:
          this.global.serverPathUser +
          this.global.url.user.getPagerUserRolesBySearch,
        isPager: true,
        pager: {
          sort: 'id.asc'
        },
        searchParams: {
          roleId: this.roleId
        }
      },
      searchUser: {
        sValue: '',
        sType: '1'
      },
      selectable: function (row, index) {
        _that.$refs.tableUser.getTable().toggleRowSelection(row, true)
      }
    }
    return data
  },
  watch: {},
  mounted () {
    this.initPageData()
  },
  methods: {
    initPageData () {},
    handleSearchUser () {
      switch (this.searchUser.sType) {
        case '1': {
          this.tableOption.searchParams = {
            loginNameLike: this.searchUser.sValue
          }
          break
        }
        case '2': {
          this.tableOption.searchParams = {
            nicknameLike: this.searchUser.sValue
          }
        }
      }
      this.tableOption.searchParams.roleId = this.roleId
      this.$refs.tableUser.initPageData()
    },
    handleRelationship (value, row) {
      if (value) {
        let _data = {
          userId: row.userId,
          roleId: this.roleId
        }
        this.$axios({
          method: 'POST',
          url: this.global.serverPathUser + this.global.url.userRoleRelationship.newRelation,
          data: _data
        })
          .then(
            function (response) {
              this.$message({
                message: this.$t('commons.messages.saveSuccess'),
                type: 'success'
              })
              row.id = response.data.id
              row.roleId = response.data.roleId

              this.handleSearchUser()
            }.bind(this)
          )
          .catch(
            function (error) {
              console.log(error)
              this.$message({
                message: this.$t('commons.messages.failedAction'),
                type: 'error'
              })
              this.handleSearchUser()
            }.bind(this)
          )
      } else {
        this.$axios({
          method: 'DELETE',
          url: this.global.serverPathUser + this.global.url.userRoleRelationship.deleteRelationById,
          urlParams: {id: row.id}
        })
          .then(
            function (response) {
              this.$message({
                message: this.$t('commons.messages.deleteSuccess'),
                type: 'success'
              })
              row.id = null
              this.handleSearchUser()
            }.bind(this)
          )
          .catch(
            function (error) {
              console.log(error)
              this.$message({
                message: this.$t('commons.messages.failedAction'),
                type: 'error'
              })
              this.handleSearchUser()
            }.bind(this)
          )
      }
    }
  }
}
</script>
<style scoped>
.search-select {
  width: 120px;
}
</style>

