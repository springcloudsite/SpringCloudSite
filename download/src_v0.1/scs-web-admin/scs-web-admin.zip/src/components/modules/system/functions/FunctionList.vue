<template>
  <transition>
    <el-container>
      <el-aside width="300px">
        <el-card shadow="never">
          <div slot="header" class="clearfix">
            <span>系统功能列表</span>
            <el-tooltip content="添加根节点" :open-delay="2000" placement="bottom" effect="light">
              <el-button class="custom-title-right" icon="fa fa-plus" type="text" @click="addRootFunctionInfo"></el-button>
            </el-tooltip>
          </div>
          <div>
            <el-input placeholder="输入关键字进行过滤" v-model="filterText"></el-input>
            <el-tree class="filter-tree" ref="functionTree" node-key="id" :data="functionTree" :props="defaultProps" default-expand-all highlight-current :expand-on-click-node="false" :filter-node-method="filterNode" @node-click="nodeClick">
              <span class="custom-tree-node" slot-scope="{ node, data }">
                <span>{{ node.label }}</span>
                <span :id="'extend-btn-' + data.id">
                  <el-tooltip content="添加" :open-delay="2000" placement="bottom" effect="light">
                    <el-button class="tree-btn" icon="fa fa-plus" type="text" @click="addFunctionInfo"></el-button>
                  </el-tooltip>
                  <el-tooltip content="修改" :open-delay="2000" placement="bottom" effect="light">
                    <el-button class="tree-btn" icon="fa fa-pencil-square-o" type="text" @click="editFunctionInfo"></el-button>
                  </el-tooltip>
                  <el-tooltip content="删除" :open-delay="2000" placement="bottom" effect="light">
                    <el-button class="tree-btn" icon="fa fa-trash-o" type="text" @click="removeFunctionInfo(node, data)"></el-button>
                  </el-tooltip>
                </span>
              </span>
            </el-tree>
          </div>
        </el-card>
      </el-aside>
      <el-main style="padding: 0 0 0 10px">
        <el-tabs :value="tabValue" type="card" @tab-click="tabClick">
          <el-tab-pane name="baseInfo" label="基本信息">
            <function-base ref="ftnBaseInfo" :function-id="curFtnId" @refreshMenuTree="initMenuTree"></function-base>
          </el-tab-pane>
          <el-tab-pane name="buttonRelationship" label="按钮管理">
            <button-list ref="btnList" :function-id="curFtnId"></button-list>
          </el-tab-pane>
          <el-tab-pane name="interfaceRelationship" label="接口管理">
            <interface-list ref="interfaceList" :function-id="curFtnId"></interface-list>
          </el-tab-pane>
        </el-tabs>
      </el-main>
    </el-container>
  </transition>
</template>
<script>
import FunctionBase from './FunctionBase.vue'
import ButtonList from './ButtonList.vue'
import InterfaceList from './InterfaceList.vue'
export default {
  name: 'function-list',
  components: {
    'function-base': FunctionBase,
    'button-list': ButtonList,
    'interface-list': InterfaceList
  },
  data () {
    let data = {
      curFtnId: '',
      filterText: '',
      functionTree: [],
      defaultProps: {
        children: 'children',
        label: 'label'
      },
      tabValue: 'baseInfo'
    }
    return data
  },
  watch: {
    filterText (val) {
      this.$refs.functionTree.filter(val)
    }
  },
  mounted () {
    this.initPageData()
  },
  methods: {
    initPageData () {
      this.initMenuTree()
    },
    initMenuTree () {
      // 初始化左侧菜单
      this.$axios({
        method: 'GET',
        url:
          this.global.serverPathUser +
          this.global.url.functions.getAllFunctionByType,
        urlParams: {
          functionType: '1'
        }
      })
        .then(
          function (response) {
            this.functionTree = this.packMenuTree(response.data, { id: null })
            if (this.functionTree.length > 0) {
              let _showId = this.curFtnId || this.functionTree[0].id
              this.$refs.functionTree.$nextTick(() => {
                this.$refs.functionTree.setCurrentKey(_showId)
                this.showTreeBtn(_showId)
                this.$refs.ftnBaseInfo.editFunctionPage(_showId)
              })
            }
          }.bind(this)
        )
        .catch(function (error) {
          console.log(error)
        })
    },
    packMenuTree (menus, parent) {
      // 封装菜单树
      let _rootMenus = []
      menus = menus || []
      if (menus.length < 1) {
        return _rootMenus
      }
      let menu = {}
      let _children = []
      for (let i = 0, count = menus.length; i < count; i++) {
        menu = menus[i]
        if (menu.parentId === parent.id) {
          _rootMenus.push({
            id: menu.id,
            code: menu.functionCode,
            label: menu.functionName,
            iconCls: menu.icon
          })
        } else {
          _children.push(menu)
        }
      }
      for (let i = 0, count = _rootMenus.length; i < count; i++) {
        _rootMenus[i].children = this.packMenuTree(_children, _rootMenus[i])
        _rootMenus[i].leaf = _rootMenus[i].children.length === 0
      }
      return _rootMenus
    },
    filterNode (value, data) {
      // 菜单数据过滤方法
      if (!value) {
        return true
      }
      return data.label.indexOf(value) !== -1
    },
    nodeClick (data, node, vm) {
      // 菜单树点击事件
      this.showTreeBtn(data.id)
    },
    showTreeBtn (nodeKey) {
      // 显示选中菜单操作按钮
      this.curFtnId = nodeKey
      $('.tree-btn-active').removeClass('tree-btn-active')
      if (nodeKey) {
        $('#extend-btn-' + nodeKey)
          .find('.tree-btn')
          .addClass('tree-btn-active')
      }
    },
    tabClick (el) {
      this.tabValue = el.name
    },
    addRootFunctionInfo () {
      // 新增根菜单
      this.curFtnId = null
      this.$refs.functionTree.setCurrentKey(null)
      this.showTreeBtn()
      this.$refs.ftnBaseInfo.newFunctionPage(true)
    },
    addFunctionInfo () {
      // 新增菜单
      this.$refs.ftnBaseInfo.newFunctionPage()
      this.$refs.btnList.initButtonData()
      this.$refs.interfaceList.initButtonData()
    },
    editFunctionInfo () {
      // 修改菜单
      this.tabValue = 'baseInfo'
      this.$refs.ftnBaseInfo.editFunctionPage()
      this.$refs.btnList.initButtonData()
      this.$refs.interfaceList.initButtonData()
    },
    removeFunctionInfo (node, data) {
      // 删除菜单

      if (!node.isLeaf) {
        this.$message({
          message: '请先删除该菜单下的所有子节点！',
          type: 'warning'
        })
        return
      }

      this.$confirm(
        this.$t('commons.messages.deleteConfirm'),
        this.$t('commons.titles.info'),
        {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }
      )
        .then(() => {
          this.$axios({
            method: 'DELETE',
            url:
              this.global.serverPathUser +
              this.global.url.functions.deleteFunction,
            urlParams: {
              id: data.id
            }
          })
            .then(
              function (response) {
                this.$message({
                  message: this.$t('commons.messages.deleteSuccess'),
                  type: 'success'
                })
                this.curFtnId = null
                this.initMenuTree()
              }.bind(this)
            )
            .catch(function (error) {
              console.log(error)
            })
        })
        .catch(() => {
          console.log('cancel delete')
        })
    }
  }
}
</script>
<style scoped>
.custom-title-right {
  float: right;
  padding: 0;
  font-size: 18px;
}
.custom-tree-node {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 14px;
  padding-right: 8px;
}
.custom-tree-node .tree-btn {
  visibility: hidden;
}
.custom-tree-node .tree-btn-active {
  visibility: visible;
}
</style>

