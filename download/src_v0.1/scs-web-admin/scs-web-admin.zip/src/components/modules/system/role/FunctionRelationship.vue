<template>
  <transition>
    <div>
      <el-row>
        <el-col :span="24">
          <el-input placeholder="输入资源名称进行过滤" v-model="filterText">
          </el-input>
        </el-col>
      </el-row>
      <el-tree ref="sourceTree" :filter-node-method="filterNode" @check-change="checkChange" node-key="functionId" :data="sourceData" default-expand-all check-strictly show-checkbox>
        <span class="custom-tree-node" slot-scope="{ node, data }">
          <i class="fa fa-bars" v-if="data.functionType === '1'" aria-hidden="true"></i>
          <i class="fa fa-th-large" v-if="data.functionType === '2'" aria-hidden="true"></i>
          <i class="fa fa-link" v-if="data.functionType === '3'" aria-hidden="true"></i>
          <span>{{ node.label }}</span>
        </span>
      </el-tree>
    </div>
  </transition>
</template>
<script>
import ScsTable from '../../../commons/ScsTable.vue'
export default {
  name: 'function-relationship',
  components: {
    'scs-table': ScsTable
  },
  props: ['roleId'],
  data () {
    let data = {
      sourceData: [],
      dataTarget: [],
      filterText: ''
    }
    return data
  },
  watch: {
    filterText (val) {
      this.$refs.sourceTree.filter(val)
    }
  },
  mounted () {
    this.initPageData()
  },
  methods: {
    initPageData () {
      this.initFunctionTreeData()
    },
    initFunctionTreeData () {
      let _roleId = this.roleId
      if (!_roleId) {
        return
      }
      let _url =
        this.global.serverPathUser +
        this.global.url.functions.getFunctionRoleBySearch
      this.$axios({
        method: 'GET',
        url: _url,
        params: {
          roleId: _roleId
        }
      })
        .then(
          function (response) {
            let data = response.data
            this.sourceData = this.initFunctionTree(data, { functionId: null })
            this.$refs.sourceTree.setCheckedKeys(this.dataTarget)
          }.bind(this)
        )
        .catch(function (error) {
          console.log(error)
        })
    },
    initFunctionTree (menus, parent) {
      let _rootMenus = []
      menus = menus || []
      if (menus.length < 1) {
        return rootMenus
      }
      let menu = {}
      let _menus = []
      for (let i = 0, count = menus.length; i < count; i++) {
        menu = menus[i]
        if (menu.parentId === parent.functionId) {
          let m = this.initFunction(menu)
          _rootMenus.push(m)
        } else {
          _menus.push(menu)
        }
      }
      for (let i = 0, count = _rootMenus.length; i < count; i++) {
        _rootMenus[i].children = this.initFunctionTree(_menus, _rootMenus[i])
        _rootMenus[i].leaf = _rootMenus[i].children.length === 0
      }
      return _rootMenus
    },
    initFunction (menu) {
      let _menu = {
        id: menu.id,
        functionId: menu.functionId,
        roleId: menu.roleId,
        code: menu.functionCode,
        label: menu.functionName,
        functionType: menu.functionType,
        disabled: menu.isDisable === '1',
        parentId: menu.parentId
      }
      if (_menu.roleId) {
        this.dataTarget.push(_menu.functionId)
      }
      return _menu
    },
    checkChange: function (data, checked, childrenChecked) {
      if (checked) {
        if (data.parentId) {
          this.$refs.sourceTree.setChecked(data.parentId, checked, false)
        }
        this.addRelationship(data)
      } else {
        if (!data.isLeaf) {
          for (let i = 0, count = data.children.length; i < count; i++) {
            this.$refs.sourceTree.setChecked(
              data.children[i].functionId,
              checked,
              false
            )
          }
        }
        this.delRelationship(data)
      }
    },
    filterNode (value, data) {
      if (!value) return true
      return data.label.indexOf(value) !== -1
    },
    addRelationship (data) {
      let _data = {
        functionId: data.functionId,
        roleId: this.roleId
      }
      this.$axios({
        method: 'POST',
        url:
            this.global.serverPathUser +
            this.global.url.functionRoleRelationship.newRelation,
        data: _data
      })
        .then(
          function (response) {
            // this.$message({
            //   message: this.$t('commons.messages.saveSuccess'),
            //   type: 'success'
            // })
            data.id = response.data.id
            data.roleId = response.data.roleId

            // this.initFunctionTreeData()
          }
        )
        .catch(
          function (error) {
            console.log(error)
            this.$message({
              message: this.$t('commons.messages.failedAction'),
              type: 'error'
            })
            this.initFunctionTreeData()
          }.bind(this)
        )
    },
    delRelationship (data) {
      this.$axios({
        method: 'DELETE',
        url:
            this.global.serverPathUser +
            this.global.url.functionRoleRelationship.deleteRelationById,
        urlParams: { id: data.id }
      })
        .then(
          function (response) {
            // this.$message({
            //   message: this.$t('commons.messages.deleteSuccess'),
            //   type: 'success'
            // })
            data.id = null
            // this.initFunctionTreeData()
          }
        )
        .catch(
          function (error) {
            console.log(error)
            this.$message({
              message: this.$t('commons.messages.failedAction'),
              type: 'error'
            })
            this.initFunctionTreeData()
          }.bind(this)
        )
    }
  }
}
</script>
<style scoped>
.search-select {
  width: 120px;
}
</style>

