<template>
  <transition>
    <div>
      <el-form :model="formUser" :rules="rulesUser" ref="formUser" label-width="150px">
        <el-form-item label="登录名称" prop="loginName">
          <el-input v-model="formUser.loginName" placeholder="请输入登录名称"></el-input>
        </el-form-item>
        <el-form-item label="用户昵称" prop="nickname">
          <el-input v-model="formUser.nickname" placeholder="请输入用户昵称"></el-input>
        </el-form-item>
        <el-form-item label="是否可用">
          <el-switch v-model="formUser.isDisable" active-value='0' inactive-value='1' active-text="启用" inactive-text="禁用"></el-switch>
        </el-form-item>
        <el-form-item label="是否删除">
          <el-switch v-model="formUser.isDelete" active-value='0' inactive-value='1' active-text="使用" inactive-text="删除"></el-switch>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="submitForm()">保存</el-button>
          <el-button @click="resetForm()">重置</el-button>
        </el-form-item>
      </el-form>
    </div>
  </transition>
</template>
<script>
export default {
  name: 'user-base',
  data () {
    let _numOrLetter = this.customValidates('numOrLetter')
    let data = {
      formUser: {
        id: '',
        loginName: '',
        nickname: '',
        isDisable: '0',
        isDelete: '0'
      },
      rulesUser: {
        loginName: [
          {
            required: true,
            message: '登录名称不能为空',
            trigger: ['blur', 'change']
          },
          {
            max: 20,
            message: '长度不能超过20字符',
            trigger: ['blur', 'change']
          },
          { validator: _numOrLetter, trigger: ['blur', 'change'] }
        ],
        nickname: [
          {
            required: true,
            message: '用户昵称不能为空',
            trigger: ['blur', 'change']
          },
          {
            max: 20,
            message: '长度不能超过20字符',
            trigger: ['blur', 'change']
          }
        ]
      }
    }
    return data
  },
  watch: {
    // userId (cur, old) {
    //   this.initUserData()
    // }
  },
  mounted () {
    this.initPageData()
  },
  methods: {
    initPageData () {
      this.initUserData()
    },
    initUserData () {
      // 初始化数据
      let _userId = this.$route.query.id
      if (_userId) {
        this.formUser.id = _userId
        this.$axios({
          method: 'GET',
          url: this.global.serverPathUser + this.global.url.user.getUserById,
          urlParams: {
            id: _userId
          }
        })
          .then(
            function (response) {
              let _data = response.data
              this.formUser = _data
            }.bind(this)
          )
          .catch(function (error) {
            console.log(error)
          })
      }
    },
    submitForm () {
      // 保存表单信息
      this.$refs.formUser.validate(valid => {
        if (valid) {
          let _data = {
            id: this.formUser.id,
            loginName: this.formUser.loginName,
            nickname: this.formUser.nickname,
            isDisable: this.formUser.isDisable,
            isDelete: this.formUser.isDelete
          }

          let _url = this.global.serverPathUser
          let _type = ''
          if (_data.id) {
            _url = _url + this.global.url.user.modifyUser
            _type = 'PATCH'
          } else {
            _url = _url + this.global.url.user.newUser
            _type = 'POST'
          }
          this.$axios({
            method: _type,
            url: _url,
            data: _data
          })
            .then(
              function (response) {
                this.$message({
                  message: this.$t('commons.messages.saveSuccess'),
                  type: 'success'
                })
                this.formUser.id = response.data.id
              }.bind(this)
            )
            .catch(function (error) {
              console.log(error)
              this.showValidateMsg(this.$refs.formUser, error, this)
            }.bind(this))
        } else {
          console.log('error submit!!')
          return false
        }
      })
    },
    resetForm () {
      // 重置表单
      this.$refs.formUser.resetFields()
    }
  }
}
</script>
<style scoped>
</style>

