<template>
  <transition>
    <div>
      <el-row>
        <scs-radio-list ref="objectTypeList" :data-options="optionRadio" @change="objectTypeChange"></scs-radio-list>
      </el-row>
      <el-container>
        <el-aside width="300px">
          <el-card shadow="never">
            <div slot="header" class="clearfix">
              <span>指标类型列表</span>
              <el-tooltip content="添加根节点" :open-delay="2000" placement="bottom" effect="light">
                <el-button class="custom-title-right" icon="fa fa-plus" type="text" @click="addRootIndexTypeInfo"></el-button>
              </el-tooltip>
            </div>
            <div>
              <el-input placeholder="输入关键字进行过滤" v-model="filterText"></el-input>
              <el-tree class="filter-tree" ref="indexTypeTree" node-key="id" :data="indexTypeTree" :props="defaultProps" default-expand-all highlight-current :expand-on-click-node="false" :filter-node-method="filterNode" @node-click="nodeClick">
                <span class="custom-tree-node" slot-scope="{ node, data }">
                  <span>{{ node.label }}</span>
                  <span :id="'extend-btn-' + data.id">
                    <el-tooltip content="添加" :open-delay="2000" placement="bottom" effect="light">
                      <el-button class="tree-btn" icon="fa fa-plus" type="text" @click="addIndexTypeInfo"></el-button>
                    </el-tooltip>
                    <el-tooltip content="修改" :open-delay="2000" placement="bottom" effect="light">
                      <el-button class="tree-btn" icon="fa fa-pencil-square-o" type="text" @click="editIndexTypeInfo"></el-button>
                    </el-tooltip>
                    <el-tooltip content="删除" :open-delay="2000" placement="bottom" effect="light">
                      <el-button class="tree-btn" icon="fa fa-trash-o" type="text" @click="removeIndexTypeInfo(node, data)"></el-button>
                    </el-tooltip>
                  </span>
                </span>
              </el-tree>
            </div>
          </el-card>
        </el-aside>
        <el-main style="padding: 0 0 0 10px">
          <el-card shadow="never">
            <div slot="header">
              <span>指标类型基本信息</span>
            </div>
            <div>
              <index-type-base ref="indexTypeBaseInfo" :index-type-id="curIndexTypeId" :object-type="objectType" @refreshIndexTypeTree="initIndexTypeTree"></index-type-base>
            </div>
          </el-card>
        </el-main>
      </el-container>
    </div>
  </transition>
</template>
<script>
import ScsRadioList from '../../commons/ScsRadioList.vue'
import IndexTypeBase from './IndexTypeBase.vue'
export default {
  name: 'index-type-management',
  components: {
    'scs-radio-list': ScsRadioList,
    'index-type-base': IndexTypeBase
  },
  data () {
    let data = {
      optionRadio: {
        url:
          this.global.serverPathScsDI +
          this.global.url.objectType.getAllObjectTypes,
        border: true,
        radioItem: {
          label: 'id',
          value: 'name'
        }
      },
      objectType: {},
      curIndexTypeId: null,
      filterText: '',
      indexTypeTree: [],
      defaultProps: {
        children: 'children',
        label: 'label'
      },
      tabValue: 'baseInfo'
    }
    return data
  },
  watch: {
    filterText (val) {
      this.$refs.indexTypeTree.filter(val)
    }
  },
  mounted () {
    this.initPageData()
  },
  methods: {
    initPageData () {
      // this.initIndexTypeTree()
    },
    initIndexTypeTree (typeid) {
      typeid = typeid || this.objectType.id
      // 初始化左侧菜单
      this.$axios({
        method: 'GET',
        url:
          this.global.serverPathScsDI +
          this.global.url.indexType.getAllByTypeid,
        urlParams: {
          typeid: typeid
        }
      })
        .then(
          function (response) {
            this.indexTypeTree = this.packIndexTypeTree(response.data, {
              id: null
            })
            if (this.indexTypeTree.length > 0) {
              let _showId = this.curIndexTypeId || this.indexTypeTree[0].id
              this.$refs.indexTypeTree.$nextTick(() => {
                this.$refs.indexTypeTree.setCurrentKey(_showId)
                this.showTreeBtn(_showId)
                this.$refs.indexTypeBaseInfo.editIndexTypePage(_showId)
              })
            } else {
              this.addRootIndexTypeInfo()
            }
          }.bind(this)
        )
        .catch(function (error) {
          console.log(error)
        })
    },
    packIndexTypeTree (items, parent) {
      // 封装菜单树
      let _rootIndexTypes = []
      items = items || []
      if (items.length < 1) {
        return _rootIndexTypes
      }
      let item = {}
      let _children = []
      for (let i = 0, count = items.length; i < count; i++) {
        item = items[i]
        if (item.parentId === parent.id) {
          _rootIndexTypes.push({
            id: item.id,
            label: item.name,
            iconCls: item.icon
          })
        } else {
          _children.push(item)
        }
      }
      for (let i = 0, count = _rootIndexTypes.length; i < count; i++) {
        _rootIndexTypes[i].children = this.packIndexTypeTree(
          _children,
          _rootIndexTypes[i]
        )
        _rootIndexTypes[i].leaf = _rootIndexTypes[i].children.length === 0
      }
      return _rootIndexTypes
    },
    filterNode (value, data) {
      // 菜单数据过滤方法
      if (!value) {
        return true
      }
      return data.label.indexOf(value) !== -1
    },
    nodeClick (data, node, vm) {
      // 菜单树点击事件
      this.showTreeBtn(data.id)
    },
    showTreeBtn (nodeKey) {
      // 显示选中菜单操作按钮
      this.curIndexTypeId = nodeKey
      $('.tree-btn-active').removeClass('tree-btn-active')
      if (nodeKey) {
        $('#extend-btn-' + nodeKey)
          .find('.tree-btn')
          .addClass('tree-btn-active')
      }
    },
    objectTypeChange (value) {
      // 对象类型变换初始化指标类型参数
      if (value) {
        this.curIndexTypeId = null
        this.initIndexTypeTree(value)
        this.objectType = this.$refs.objectTypeList.getSelectData()
      }
    },
    tabClick (el) {
      this.tabValue = el.name
    },
    addRootIndexTypeInfo () {
      // 新增根菜单
      this.curIndexTypeId = null
      this.$refs.indexTypeTree.setCurrentKey(null)
      this.showTreeBtn()
      this.$refs.indexTypeBaseInfo.newIndexTypePage(true)
    },
    addIndexTypeInfo () {
      // 新增菜单
      this.$refs.indexTypeBaseInfo.newIndexTypePage()
    },
    editIndexTypeInfo () {
      // 修改菜单
      this.tabValue = 'baseInfo'
      this.$refs.indexTypeBaseInfo.editIndexTypePage()
    },
    removeIndexTypeInfo (node, data) {
      // 删除菜单

      if (!node.isLeaf) {
        this.$message({
          message: '请先删除该菜单下的所有子节点！',
          type: 'warning'
        })
        return
      }

      this.$confirm(
        this.$t('commons.messages.deleteConfirm'),
        this.$t('commons.titles.info'),
        {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }
      )
        .then(() => {
          this.$axios({
            method: 'DELETE',
            url:
              this.global.serverPathScsDI +
              this.global.url.indexType.deleteIndexTypeById,
            urlParams: {
              id: data.id
            }
          })
            .then(
              function (response) {
                this.$message({
                  message: this.$t('commons.messages.deleteSuccess'),
                  type: 'success'
                })
                this.curIndexTypeId = null
                this.initIndexTypeTree()
              }.bind(this)
            )
            .catch(function (error) {
              console.log(error)
            })
        })
        .catch(() => {
          console.log('cancel delete')
        })
    }
  }
}
</script>
<style scoped>
.custom-title-right {
  float: right;
  padding: 0;
  font-size: 18px;
}
.custom-tree-node {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 14px;
  padding-right: 8px;
}
.custom-tree-node .tree-btn {
  visibility: hidden;
}
.custom-tree-node .tree-btn-active {
  visibility: visible;
}
</style>
