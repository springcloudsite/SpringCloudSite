<template>
  <transition>
    <div>
      <el-row>
        <el-col :span="24">
          <el-form label-width="150px">
            <el-form-item label="对象类型">
              <span>{{formIndexType.objectType}}</span>
            </el-form-item>
            <el-form-item label="父级节点">
              <span>{{formIndexType.parentTypeName}}</span>
            </el-form-item>
          </el-form>
        </el-col>
      </el-row>
      <el-form :model="formIndexType" :rules="rulesIndexType" ref="formIndexType" label-width="150px">
        <el-form-item label="指标类型名称" prop="name">
          <el-input v-model="formIndexType.name" placeholder="请输入指标类型名称"></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="submitForm()">保存</el-button>
          <el-button @click="resetForm()">重置</el-button>
        </el-form-item>
      </el-form>
    </div>
  </transition>
</template>
<script>
export default {
  name: 'index-type-base',
  props: {
    indexTypeId: {
      type: Number
    },
    objectType: {
      type: Object,
      default: function () {
        return {}
      }
    }
  },
  data () {
    let data = {
      formIndexType: {
        id: '',
        parentId: '',
        parentTypeName: '无',
        objectType: this.objectType.name || '无',
        typeid: this.objectType.id || '',
        name: ''
      },
      rulesIndexType: {
        name: [
          {
            required: true,
            message: '标类型名称不能为空',
            trigger: ['blur', 'change']
          },
          {
            max: 250,
            message: '长度不能超过250字符',
            trigger: ['blur', 'change']
          }
        ]
      }
    }
    return data
  },
  watch: {
    objectType (cur, old) {
      if (!this.formIndexType.id) {
        this.initObjectTypeData()
      }
    }
  },
  mounted () {
    this.initPageData()
  },
  methods: {
    initPageData () {
      this.initIndexTypeData()
    },
    initIndexTypeData (indexTypeId) {
      // 初始化数据
      let _indexTypeId = indexTypeId || this.indexTypeId
      if (_indexTypeId) {
        this.$axios({
          method: 'GET',
          url: this.global.serverPathScsDI + this.global.url.indexType.getIndexTypeById,
          urlParams: {
            id: _indexTypeId
          }
        })
          .then(
            function (response) {
              let _data = response.data
              this.formIndexType = _data
              this.formIndexType.parentTypeName = _data.parentTypeName || '无'
            }.bind(this)
          )
          .catch(function (error) {
            console.log(error)
          })
      }
    },
    initObjectTypeData () {
      this.formIndexType.objectType = this.objectType.name || '无'
      this.formIndexType.typeid = this.objectType.id || ''
    },
    newIndexTypePage (isRoot) {
      // 新建页面初始化数据
      this.formIndexType = {
        id: '',
        parentId: '',
        parentTypeName: '无',
        objectType: '',
        typeid: '',
        name: ''
      }
      this.initObjectTypeData()
      this.resetForm()
      let _indexTypeId = isRoot ? '' : this.indexTypeId
      if (_indexTypeId) {
        this.$axios({
          method: 'GET',
          url: this.global.serverPathScsDI + this.global.url.indexType.getIndexTypeById,
          urlParams: {
            id: _indexTypeId
          }
        })
          .then(
            function (response) {
              let _data = response.data
              this.formIndexType.parentId = _data.id
              this.formIndexType.parentTypeName = _data.name || '无'
            }.bind(this)
          )
          .catch(function (error) {
            console.log(error)
          })
      }
    },
    editIndexTypePage (indexTypeId) {
      // 初始化编辑数据
      this.initIndexTypeData(indexTypeId)
    },
    submitForm () {
      // 保存表单信息
      this.$refs.formIndexType.validate(valid => {
        if (valid) {
          let _data = {
            id: this.formIndexType.id,
            parentId: this.formIndexType.parentId,
            typeid: this.formIndexType.typeid,
            name: this.formIndexType.name
          }

          let _url = this.global.serverPathScsDI
          let _type = ''
          if (_data.id) {
            _url = _url + this.global.url.indexType.modifyIndexType
            _type = 'PATCH'
          } else {
            _url = _url + this.global.url.indexType.newIndexType
            _type = 'POST'
          }
          this.$axios({
            method: _type,
            url: _url,
            data: _data
          })
            .then(
              function (response) {
                this.$message({
                  message: this.$t('commons.messages.saveSuccess'),
                  type: 'success'
                })
                this.formIndexType.id = response.data.id
                this.$emit('refreshIndexTypeTree')
              }.bind(this)
            )
            .catch(function (error) {
              console.log(error)
              this.showValidateMsg(this.$refs.formIndexType, error, this)
            }.bind(this))
        } else {
          console.log('error submit!!')
          return false
        }
      })
    },
    resetForm () {
      // 重置表单
      this.$refs.formIndexType.resetFields()
    }
  }
}
</script>
<style scoped>
</style>

