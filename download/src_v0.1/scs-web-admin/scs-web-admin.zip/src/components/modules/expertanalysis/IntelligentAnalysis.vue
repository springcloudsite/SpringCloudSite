<template>
  <el-row>
    <el-col :span="6">
      <div>
        <el-tree ref="indexTree" :data="treeOption.indexDatas" node-key="id" :props="treeOption.defaultProps" @check-change="handleCheckChange" check-on-click-node highlight-current default-expand-all show-checkbox></el-tree>
      </div>
      <div>
        <div v-for="task in taskList" :key="task.id">
          <a :data-id="task.id" href="javascript:void(0)" @click="showTaskDetails($event)">{{task.name}}</a>
        </div>
      </div>
    </el-col>
    <el-col :span="18">
      <scs-table class="mb20" ref="parameterTable" :table-option="tableOption"></scs-table>
      <el-dialog title="参数设置" :visible.sync="indexSelector.open">
        <template v-if="indexSelector.indexType === 'time'">
          <time-selector ref="timeSelector"></time-selector>
        </template>
        <template v-else>
          <type-selector ref="typeSelector"></type-selector>
        </template>
        <div class="dialog-footer" slot="footer">
          <el-button @click="indexSelector.open = false">取 消</el-button>
          <el-button type="primary" @click="handleTypeSelector">确 定</el-button>
        </div>
      </el-dialog>
      <el-row>
        <el-col :span="24">
          <el-button type="danger" @click="runAnalysis">执行</el-button>
          <el-button type="primary">保存方案</el-button>
          <el-button type="">导出到Excel</el-button>
          <el-button type="">导出到分析数据</el-button>
        </el-col>
      </el-row>
      <template v-if="showAnalysisTable">
        <scs-table :table-option="tableOptionAnalysis"></scs-table>
      </template>
    </el-col>
  </el-row>
</template>
<script>
import ScsTable from '../../commons/ScsTable.vue'
import TypeSelector from './parametersetting/TypeSelector.vue'
import TimeSelector from './parametersetting/TimeSelector.vue'

export default {
  name: 'intelligent-analysis',
  components: {
    'scs-table': ScsTable,
    'type-selector': TypeSelector,
    'time-selector': TimeSelector
  },
  data () {
    let _that = this
    let data = {
      treeOption: {
        indexDatas: [],
        defaultProps: {
          children: 'children',
          label: 'label'
        }
      },
      tableOption: {
        showNum: true,
        columns: [
          {
            prop: 'indexName',
            label: '指标名称'
          },
          {
            prop: 'seleter',
            label: '选择器',
            renderCell: function (h, scope) {
              let row = scope.row
              return h(
                'a',
                {
                  attrs: {
                    href: 'javascript:void(0)'
                  },
                  on: {
                    click: function () {
                      _that.indexSelector = {
                        indexCheck: row.id,
                        indexType: row.indexType,
                        open: true
                      }
                    }
                  }
                },
                '参数设置'
              )
            }
          },
          {
            prop: 'parameterName',
            label: '参数'
          },
          {
            prop: 'operator',
            label: '运算符'
          },
          {
            prop: 'parameterValue',
            label: '数值'
          },
          {
            prop: 'unit',
            label: '单位'
          },
          {
            prop: 'ifShow',
            label: '显示',
            renderCell: function (h, scope) {
              let row = scope.row
              return h(
                'el-switch',
                {
                  attrs: {
                    value: row.ifShow
                  },
                  on: {
                    input: value => {
                      row.ifShow = value
                    }
                  }
                },
                '编辑'
              )
            }
          }
        ],
        datas: []
      },
      tableOptionAnalysis: {
        columns: [],
        datas: []
      },
      taskList: [],
      indexSelector: {
        open: false,
        indexCheck: '',
        indexType: ''
      },
      showAnalysisTable: false
    }
    return data
  },
  mounted () {
    this.initPageData()
  },
  methods: {
    initPageData () {
      this.initIndexTree()
      this.initTask()
    },
    initIndexTree () {
      this.$axios({
        method: 'GET',
        url:
          this.global.serverPathScsDI +
          this.global.url.parameters.getIndexsTree,
        params: {}
      })
        .then(
          function (response) {
            this.treeOption.indexDatas = response.data.datas
          }.bind(this)
        )
        .catch(function (error) {
          console.log(error)
        })
    },
    initTask () {
      this.$axios({
        method: 'GET',
        url:
          this.global.serverPathScsDI +
          this.global.url.parameters.getTasks,
        params: {}
      })
        .then(
          function (response) {
            this.taskList = response.data.datas
          }.bind(this)
        )
        .catch(function (error) {
          console.log(error)
        })
    },
    showTaskDetails (event) {
      let _this = event.toElement
      console.log($(_this).attr('data-id'))
    },
    handleCheckChange (data, checked, childChecked) {
      let node = this.$refs.indexTree.getNode(data.id)
      if (!node.isLeaf) {
        return
      }
      if (checked) {
        let d = {
          id: data.id,
          indexType: data.indexType || 'index',
          indexName: data.label,
          parameterName: '',
          operator: '',
          parameterValue: '',
          unit: '',
          ifShow: true
        }
        this.tableOption.datas.push(d)
      } else {
        let datas = this.tableOption.datas
        for (let i = 0, count = datas.length; i < count; i++) {
          if (datas[i].id === data.id) {
            datas.splice(i, 1)
            break
          }
        }
      }
    },
    handleTypeSelector () {
      let value = {}
      switch (this.indexSelector.indexType) {
        case 'time': {
          value = this.$refs.timeSelector.getValue()
          break
        }
        default: {
          value = this.$refs.typeSelector.getValue()
        }
      }
      let datas = this.tableOption.datas
      for (let i = 0, count = datas.length; i < count; i++) {
        if (datas[i].id === this.indexSelector.indexCheck) {
          datas[i].parameterName = value.index
          datas[i].operator = value.operator
          datas[i].parameterValue = value.value
          datas[i].unit = value.unit
          break
        }
      }
      console.log(this.tableOption.datas)
      this.indexSelector.open = false
    },
    runAnalysis () {
      let tDatas = this.$refs.parameterTable.getTableDatas()
      let count = tDatas.length
      if (count < 1) {
        this.$message.error('请选择指标')
        return
      }
      let showDatas = []
      let data = null
      for (let i = 0; i < count; i++) {
        data = tDatas[i]
        if (data.ifShow) {
          showDatas.push({
            id: data.id,
            indexType: data.indexType,
            indexName: data.indexName,
            parameterName: data.parameterName,
            operator: data.operator,
            parameterValue: data.parameterValue,
            unit: data.unit
          })
        }
      }
      if (showDatas.length > 0) {
        this.$axios({
          method: 'post',
          url:
            this.global.serverPathScsDI +
            this.global.url.parameters.runIntelligentAnalisys,
          data: {
            indexs: showDatas
          }
        })
          .then(
            function (response) {
              console.log(response.data.datas)
              this.tableOptionAnalysis = response.data.datas
            }.bind(this)
          )
          .catch(function (error) {
            console.log(error)
          })
        let taskId = new Date().getTime()
        this.taskList.splice(0, 0, {
          id: taskId,
          name: 'Task-' + taskId
        })
        this.showAnalysisTable = true
      } else {
        this.$message.error('请选择要显示的指标')
      }
    }
  }
}
</script>