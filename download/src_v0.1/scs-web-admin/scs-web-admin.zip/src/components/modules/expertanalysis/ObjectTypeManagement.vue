<template>
  <div>
    <el-row>
      <el-col :span="24">
        <el-input placeholder="请输入内容" v-model="searchObjectType.sValue">
          <el-select class="search-select" v-model="searchObjectType.sType" slot="prepend" placeholder="请选择">
            <el-option label="对象类型名称" value="1"></el-option>
          </el-select>
          <el-button slot="append" icon="el-icon-search" @click="handleSearchObjectType"></el-button>
        </el-input>
      </el-col>
    </el-row>
    <scs-table ref="tableObjectType" :table-option="tableOption"></scs-table>
  </div>
</template>

<script>
import ScsTable from '../../commons/ScsTable.vue'
export default {
  name: 'object-type-management',
  components: {
    'scs-table': ScsTable
  },
  data () {
    let _that = this
    return {
      tableOption: {
        showNum: true,
        // showSelection: true,
        columns: [
          {
            prop: 'name',
            label: '分析对象类型名称'
          },
          {
            prop: 'founder',
            label: '创建人'
          },
          {
            prop: 'action',
            label: '操作',
            renderCell: function (h, scope) {
              let row = scope.row
              return h('div', [
                h(
                  'el-button',
                  {
                    props: {
                      size: 'mini',
                      type: 'primary'
                    },
                    on: {
                      click: () => {
                        _that.loadModifyPage(row.id)
                      }
                    }
                  },
                  '编辑'
                ),
                h(
                  'el-button',
                  {
                    props: {
                      size: 'mini',
                      type: 'danger'
                    },
                    on: {
                      click: () => {
                        _that.removeObjectTypeInfo(row.id)
                      }
                    }
                  },
                  '删除'
                )
              ])
            }
          }
        ],
        datas: [],
        dataUrl:
          this.global.serverPathScsDI +
          this.global.url.objectType.getObjectTypesBySearch,
        // isPager: true,
        buttons: [
          {
            code: 'add',
            click: function () {
              _that.$router.push({ path: '/object-type-base' })
            }
          }
        ],
        pager: {
          sort: 'id.asc'
        },
        searchParams: {}
      },
      searchObjectType: {
        sValue: '',
        sType: '1'
      }
    }
  },
  methods: {
    removeObjectTypeInfo (id) {
      this.$confirm(
        this.$t('commons.messages.deleteConfirm'),
        this.$t('commons.titles.info'),
        {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }
      )
        .then(() => {
          this.$axios({
            method: 'DELETE',
            url:
              this.global.serverPathScsDI +
              this.global.url.objectType.deleteObjectTypeById,
            urlParams: {
              id: id
            }
          })
            .then(
              function (response) {
                this.$message({
                  message: this.$t('commons.messages.deleteSuccess'),
                  type: 'success'
                })
                this.handleSearchObjectType()
              }.bind(this)
            )
            .catch(
              function (error) {
                console.log(error)
                this.showValidateMsg(null, error, this)
              }.bind(this)
            )
        })
        .catch(() => {
          console.log('cancel delete')
        })
    },
    handleSearchObjectType () {
      switch (this.searchObjectType.sType) {
        case '1': {
          this.tableOption.searchParams = {
            nameLike: this.searchObjectType.sValue
          }
          break
        }
      }
      this.$refs.tableObjectType.initPageData()
    },
    loadModifyPage (id) {
      this.$router.push({ path: '/object-type-base', query: { id: id } })
    }
  }
}
</script>
<style scoped>
.search-select {
  width: 140px;
}
</style>
