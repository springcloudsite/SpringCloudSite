<template>
  <transition>
    <div>
      <el-tabs :value="tabValue" type="card" @tab-click="tabClick">
        <el-tab-pane name="baseInfo" label="基本信息">
          <el-form :model="formObjectType" :rules="rulesObjectType" ref="formObjectType" label-width="150px">
            <el-form-item label="对象类型名称" prop="name">
              <el-input v-model="formObjectType.name" placeholder="请输入对象类型名称"></el-input>
            </el-form-item>
            <el-form-item>
              <el-button type="primary" @click="submitForm()">保存</el-button>
              <el-button @click="resetForm()">重置</el-button>
            </el-form-item>
          </el-form>
        </el-tab-pane>
        <el-tab-pane name="functionRelationship" label="指标管理" :disabled="isTabDisable" lazy>
          <index-relationship :object-type-id="formObjectType.id"></index-relationship>
        </el-tab-pane>
      </el-tabs>
    </div>
  </transition>
</template>
<script>
import IndexRelationship from '../system/role/UserRelationship.vue'
export default {
  name: 'object-type-base',
  components: {
    'index-relationship': IndexRelationship
  },
  data () {
    let data = {
      isTabDisable: true,
      tabValue: 'baseInfo',
      formObjectType: {
        id: this.$route.query.id || '',
        name: ''
      },
      rulesObjectType: {
        name: [
          {
            required: true,
            message: '对象类型名称不能为空',
            trigger: ['blur', 'change']
          },
          {
            max: 100,
            message: '长度不能超过100字符',
            trigger: ['blur', 'change']
          }
        ]
      }
    }
    return data
  },
  watch: {
    // roleId (cur, old) {
    //   this.initObjectTypeData()
    // }
  },
  mounted () {
    this.initPageData()
  },
  methods: {
    initPageData () {
      this.initObjectTypeData()
    },
    initObjectTypeData () {
      // 初始化数据
      let _objectTypeId = this.formObjectType.id
      if (_objectTypeId) {
        this.$axios({
          method: 'GET',
          url: this.global.serverPathScsDI + this.global.url.objectType.getObjectTypeById,
          urlParams: {
            id: _objectTypeId
          }
        })
          .then(
            function (response) {
              let _data = response.data
              this.formObjectType = _data
              this.isTabDisable = false
            }.bind(this)
          )
          .catch(function (error) {
            console.log(error)
          })
      }
    },
    submitForm () {
      // 保存表单信息
      this.$refs.formObjectType.validate(valid => {
        if (valid) {
          let _data = {
            id: this.formObjectType.id,
            name: this.formObjectType.name
          }

          let _url = this.global.serverPathScsDI
          let _type = ''
          if (_data.id) {
            _url = _url + this.global.url.objectType.modifyObjectType
            _type = 'PATCH'
          } else {
            _url = _url + this.global.url.objectType.newObjectType
            _type = 'POST'
          }
          this.$axios({
            method: _type,
            url: _url,
            data: _data
          })
            .then(
              function (response) {
                this.$message({
                  message: this.$t('commons.messages.saveSuccess'),
                  type: 'success'
                })
                this.formObjectType.id = response.data.id
                this.isTabDisable = false
              }.bind(this)
            )
            .catch(
              function (error) {
                console.log(error)
                this.showValidateMsg(this.$refs.formObjectType, error, this)
              }.bind(this)
            )
        } else {
          console.log('error submit!!')
          return false
        }
      })
    },
    resetForm () {
      // 重置表单
      this.$refs.formObjectType.resetFields()
    },
    tabClick (el) {
      // tab页签转换
      this.tabValue = el.name
    }
  }
}
</script>
<style scoped>
</style>