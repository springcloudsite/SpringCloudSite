<template>
  <div>
    <div v-if="!disabled">
      <Upload :accept="accept" :headers="headers" :show-upload-list="true" :default-file-list="fileList" :before-upload="renameFile" :on-remove="removeFile" :on-success="handleSuccess" :action="parentData.url" :on-preview="downloadFile">
        <Button :disabled="isMax" type="ghost" @click="selfClick">{{parentData.buttonName}}</Button>
      </Upload>
    </div>
    <div v-else>
      <div v-for="file in fileList" :key="file.id">
        <a href="javascript:void(0)" @click="downloadFile(file)">{{file.name}}</a>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'file-upload',
  data () {
    let data = {
      renameFileName: '',
      fileList: [],
      defaultFileList: [],
      deleteFileIds: [],
      currentId: '',
      isMax: false,
      headers: {
        'www-Authorization': localStorage.getItem('current-admin-token') || ''
      }
    }
    return data
  },
  props: ['disabled', 'parentData', 'limit', 'accept'],
  mounted () {
    // this.limit = 1
  },
  updated: function () {
    if (this.limit < 0) {
      this.isMax = false
    } else {
      this.isMax = this.fileList.length >= this.limit
    }
  },
  methods: {
    selfClick () {
      if ($.isFunction(this.parentData.beforeClick)) {
        this.parentData.beforeClick()
      }
    },
    setFileList (files) {
      this.fileList = files || []
    },
    getFileList () {
      return this.fileList
    },
    getDeleteFileIds () {
      return this.deleteFileIds
    },
    handleSuccess (res, file, list) {
      file.tid = this.currentId
      if (this.renameFileName) {
        file.name = this.renameFileName
      }
      if (this.parentData.downloadUrl) {
        file.url = '/file' + this.parentData.downloadUrl + res
      }
      this.fileList.push(file)
    },
    renameFile (file) {
      this.currentId = new Date().getTime()
      // 文件重命名方法
      this.$Modal.confirm({
        onOk: () => {
          this.renameFileName = this.renameFileName || file.name
          for (let i = this.fileList.length - 1; i > -1; i--) {
            if (this.currentId === this.fileList[i].tid) {
              this.fileList[i].name = this.renameFileName
              this.renameFileName = ''
              break
            }
          }
        },
        render: h => {
          return h('Input', {
            props: {
              value: file.name,
              autofocus: true
            },
            on: {
              input: val => {
                this.renameFileName = val
              }
            }
          })
        }
      })
      return true
    },
    removeFile (file) {
      // 文件删除方法
      var matchi = -1
      for (var i = 0, count = this.fileList.length; i < count; i++) {
        if (file.uid === this.fileList[i].uid) {
          matchi = i
          break
        }
      }
      if (matchi !== -1) {
        let id = this.fileList[matchi].id
        if (id) {
          this.deleteFileIds.push(id)
        }
        this.fileList.splice(matchi, 1)
      }
    },
    downloadFile: function (file) {
      console.log(file)
      window.open(this.global.serverFile + file.url + '?' + 'www-Authorization=' + localStorage.getItem('current-admin-token') || '', '_blank')
    }
  }
}
</script>