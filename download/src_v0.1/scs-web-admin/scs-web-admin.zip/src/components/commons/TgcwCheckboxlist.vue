<template>
    <CheckboxGroup v-model="arrayvalues"  @on-change="select">
  <Checkbox v-for="item in dictList" :key="item.code" :label="item.code" >
         <span>{{item.label}}</span>
  </Checkbox>
    </CheckboxGroup>
</template>
<script>
import TgcwCheckboxlist from './TgcwCheckboxlist.vue'
export default {
  data () {
    return {
      url: this.global.serverSys + this.global.url.sysdictionary + '/',
      arrayvalues: [],
      dictList: []
    }
  },
  components: {
    TgcwCheckboxlist
  },

  props: ['datatype', 'default'],
  mounted () {
    this.$axios({
      method: 'get',
      url: this.url + this.datatype
    }).then(function (response) {
      this.dictList = response.data
    }.bind(this)).catch(function (error) {
      console.log(error)
    })
    if (this.default) {
      this.arrayvalues = this.default.split(',')
    }
  },
  methods: {
    select: function () {
      this.$emit('ref', this.arrayvalues)
    },
    // 父组件设置值
    set: function (arrayfromparent) {
      var newarray = []
      var str = ''
      for (var i = 0; i <= arrayfromparent.length - 1; i++) {
      //  console.log(arrayfromparent[i])
        str += arrayfromparent[i].code + ','
      }
      newarray = str.split(',')
      newarray.pop()
      this.arrayvalues = newarray
    },
    update: function (typearg) {
      this.$axios({
        method: 'get',
        url: this.url + typearg
      }).then(function (response) {
        this.dictList = response.data
      }.bind(this)).catch(function (error) {
        console.log(error)
      })
      if (this.default) {
        this.arrayvalues = this.default.split(',')
      }
    }
  }
}

</script>