<template>
  <el-radio-group v-model="checkValue" @change="select">
    <el-radio v-for="item in dataRadios" :key="item.id" :label="item[radioItem.label]" :border="border" :disabled="!!item[radioItem.disabled]">
      {{item[radioItem.value]}}
    </el-radio>
  </el-radio-group>
</template>
<script>
/**
 * dataOptions = {
 *   url: '', // 远程查询地址
 *   dataValue: [
 *     {
 *       id:'', // 选中值
 *       label: '', // 显示值
 *       disabled: false, // 是否禁用
 *     }
 *   ], // 本地数据
 *   checkValue: '', // 选中值
 *   border: false, // 是否带边框
 *   radioItem: { // 显示字段控制
 *     label: 'label', // 选中值
 *     value: 'value', // 显示值
 *     disabled: 'disabled' // 禁用显示
 *   }
 * }
 */
export default {
  name: 'scs-radio-list',
  props: {
    dataOptions: {
      type: Object,
      required: true,
      default: function () {
        return {}
      },
      validator: function (value) {
        return !!value
      }
    }
  },
  data () {
    let _opt = this.dataOptions
    let _data = {
      url: _opt.url,
      border: !!_opt.border,
      checkValue: _opt.checkValue || '',
      dataRadios: _opt.dataValue || [],
      radioItem: {
        label: _opt.radioItem.label || 'id',
        value: _opt.radioItem.value || 'value',
        disabled: _opt.radioItem.disabled || 'disabled'
      }
    }
    return _data
  },
  mounted () {
    if (this.url) {
      this.$axios({
        method: 'GET',
        url: this.url
      })
        .then(
          function (response) {
            this.dataRadios = response.data
            this.defaultCheckValue()
          }.bind(this)
        )
        .catch(function (error) {
          console.log(error)
        })
    } else {
      this.defaultCheckValue()
    }
  },
  methods: {
    defaultCheckValue () {
      // 判断默认选中的值 当checkValue为null时默认选中第一个选项
      if (!this.checkValue) {
        let _datas = this.dataRadios || []
        if (_datas.length > 0) {
          this.checkValue = _datas[0][this.radioItem.label]
          this.select(this.checkValue)
        }
      }
    },
    select (value) {
      // 选中改变时触发事件
      this.$emit('change', value)
    },
    getSelect () {
      // 获取选中的值
      return this.select
    },
    getSelectData () {
      // 获取选中对象
      let _datas = this.dataRadios || []
      let _curSelect = this.checkValue
      let _key = this.radioItem.label
      let _data = {}
      for (let i = 0, count = _datas.length; i < count; i++) {
        if (_curSelect === _datas[i][_key]) {
          _data = _datas[i]
          break
        }
      }
      return _data
    }
  }
}
</script>