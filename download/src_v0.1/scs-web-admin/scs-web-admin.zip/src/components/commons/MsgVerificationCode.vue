<template>
  <div>
    <Button type="primary" long :loading="msgVCodeLoading !== 1" @click="loadChange">
      <span v-if="msgVCodeLoading === 1">获取验证码</span>
      <span v-else-if="msgVCodeLoading === 2">正在获取验证码</span>
      <span v-else>{{backwardNum}}秒后重新获取</span>
    </Button>
  </div>
</template>

<script>
export default {
  name: 'msgVerificationCode',
  data () {
    let data = {
      msgVCodeLoading: 1,
      backwardNum: 60,
      toLoading: true
    }
    return data
  },
  props: ['parentData', 'token'],
  methods: {
    loadChange: function () {
      if ($.isFunction(this.parentData.parentValidateFn)) {
        if (this.parentData.parentValidateFn()) {
          this.loadValidate()
        }
      }
    },
    loadValidate: function () {
      if (this.toLoading) {
        this.msgVCodeLoading = 2
        this.toLoading = false
      } else {
        return
      }
      let url =
        this.global.userManagementPath +
        this.global.url.user.msgVCode +
        this.parentData.mobilePhone

      this.$axios({
        method: 'GET',
        url: url,
        params: {
          token: this.token,
          vcode: this.parentData.vCode,
          checkType: this.parentData.checkType
        }
      })
        .then(
          function (response) {
            let data = response.data
            if (data) {
              let e = this.parentData.parentCallBackFn(data)
              if (e) {
                this.resetStatus()
                return
              } else {
                if (response.status !== 200) {
                  console.error(data.errorCode)
                  let msg = this.$t(data.errorCode) || '请重新获取短信验证码'
                  this.$Message.error(msg)
                  this.resetStatus()
                  return
                }
              }
            }
            this.runCountBackwards()
          }.bind(this)
        )
        .catch(
          function (error) {
            console.log(error.response)
            if (error.response) {
              let e = this.parentData.parentCallBackFn(error.response.data)
              if (!e) {
                let msg = this.$t(error.response.data.errorCode) || '请重新获取短信验证码'
                this.$Message.error(msg)
              }
            }
            this.resetStatus()
          }.bind(this)
        )
    },
    resetStatus: function () {
      this.toLoading = true
      this.msgVCodeLoading = 1
      window.sessionStorage.removeItem('count-backwards')
      this.$emit('get-random')
    },
    countBackwards: function (id) {
      let num = this.backwardNum - 1
      this.backwardNum = num
      let cb = {
        timestamp: new Date().getTime(),
        backwardNum: num
      }
      window.sessionStorage.setItem('count-backwards', JSON.stringify(cb))
      if (num < 1) {
        this.msgVCodeLoading = 1
        this.toLoading = true
        window.sessionStorage.removeItem('count-backwards')
        this.backwardNum = 60
        clearInterval(id)
      }
    },
    runCountBackwards: function () {
      if (this.backwardNum >= 60) {
        this.msgVCodeLoading = 3
        let id = setInterval(
          function () {
            this.countBackwards(id)
          }.bind(this),
          1000
        )
      }
    }
  },
  mounted: function () {
    let cb = window.sessionStorage.getItem('count-backwards')
    if (cb) {
      cb = JSON.parse(cb)
      let timestamp = new Date().getTime() - cb.timestamp
      if (timestamp < (cb.backwardNum * 1000)) {
        this.msgVCodeLoading = 3
        this.backwardNum = cb.backwardNum - parseInt(timestamp / 1000)
        let id = setInterval(
          function () {
            this.countBackwards(id)
          }.bind(this),
          1000
        )
      } else {
        window.sessionStorage.removeItem('count-backwards')
      }
    }
  }
}
</script>
<style>
</style>
