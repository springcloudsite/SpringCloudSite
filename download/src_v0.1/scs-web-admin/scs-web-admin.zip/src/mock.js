// 引入mockjs
import Mock from 'mockjs'
import global from './Global'
// 获取 mock.Random 对象
const Random = Mock.Random
// mock一组数据
const mockIndexTree = function (request) {
  // 查询指标树数据
  let result = [
    {
      id: '11',
      label: '基础信息',
      children: [
        {
          id: '1',
          label: '面积'
        },
        {
          id: '2',
          label: '区域',
          indexType: 'time'
        },
        {
          id: '3',
          label: '官网长度'
        },
        {
          id: '4',
          label: '所属热源'
        }
      ]
    },
    {
      id: '12',
      label: '收费指标',
      children: [
        {
          id: '5',
          label: '收费总额'
        },
        {
          id: '6',
          label: '收费类型'
        },
        {
          id: '7',
          label: '退费总额'
        },
        {
          id: '8',
          label: '见面总额'
        }
      ]
    },
    {
      id: '13',
      label: '生产指标',
      children: [
        {
          id: '15',
          label: '热力站',
          children: [
            {
              id: '9',
              label: '一次入口温度'
            },
            {
              id: '10',
              label: '一次压力'
            }
          ]
        }
      ]
    },
    {
      id: '14',
      label: '客服指标'
    }
  ]
  if (request.body) {
    let params = JSON.parse(request.body)
    switch (params.objectType) {
      case '1': {
        result = [
          {
            id: '13',
            label: '生产指标',
            children: [
              {
                id: '15',
                label: '热力站',
                children: [
                  {
                    id: '9',
                    label: '一次入口温度'
                  },
                  {
                    id: '10',
                    label: '一次压力'
                  }
                ]
              }
            ]
          }
        ]
      }
    }
  }
  return {
    datas: result
  }
}

const mockFunctionTree = function (request) {
  // 查询指标树数据
  let result = [
    {
      id: '11',
      label: '回归',
      children: [
        {
          id: '1',
          label: 'GradienDescent(梯度)'
        },
        {
          id: '2',
          label: '最小二乘方',
          indexType: 'time'
        },
        {
          id: '3',
          label: 'RegTree(回归树)'
        },
        {
          id: '4',
          label: 'logRegres(逻辑回归)'
        },
        {
          id: '5',
          label: 'BP(反向传播神经网络)'
        }
      ]
    },
    {
      id: '12',
      label: '分类',
      children: [
        {
          id: '6',
          label: 'SVM'
        },
        {
          id: '7',
          label: 'FpGrowth(频繁模式)'
        },
        {
          id: '8',
          label: 'Apriori(关联分析)'
        },
        {
          id: '9',
          label: 'Adaboost(迭代算法)'
        }
      ]
    },
    {
      id: '13',
      label: '聚类',
      children: [
        {
          id: '15',
          label: '聚合',
          children: [
            {
              id: '10',
              label: 'Kmeans'
            },
            {
              id: '11',
              label: 'KNN'
            }
          ]
        }
      ]
    },
    {
      id: '14',
      label: '概率',
      children: [
        {
          id: '15',
          label: '统计',
          children: [
            {
              id: '17',
              label: 'Bayes(贝叶斯)'
            },
            {
              id: '16',
              label: 'TreeClassifier(决策树)'
            }
          ]
        }
      ]
    }
  ]
  return {
    datas: result
  }
}

const mockRunIntelligentAnalysis = function (request) {
  // 指标分析
  let params = JSON.parse(request.body)
  let indexs = params.indexs
  let columns = [{
    prop: 'stationName',
    label: '站名'
  }]
  let iCount = indexs.length
  for (let i = 0; i < iCount; i++) {
    columns.push({
      prop: 'index' + i,
      label: indexs[i].indexName + '(' + indexs[i].unit + ')'
    })
  }
  let stations = ['文思海辉地下', '周水子机场']
  let datas = []
  for (let i = 0, count = stations.length; i < count; i++) {
    let d = {}
    d.stationName = stations[i]
    for (let j = 0; j < iCount; j++) {
      d['index' + j] = Random.integer()
    }
    datas.push(d)
  }
  let result = {
    columns: columns,
    datas: datas
  }
  return {
    datas: result
  }
}

const mockTaskList = function () {
  // 查询任务结果
  let result = []
  for (let i = 0; i < 3; i++) {
    result.splice(0, 0, {
      id: Random.id(),
      name: 'Task-' + new Date().getTime()
    })
  }
  return {
    datas: result
  }
}

const mockObjectTypeList = function (request) {
  // 对象类型
  let result = [{
    id: '1',
    name: '热力站'
  }]
  return {
    datas: result
  }
}

const mockCompanyTable = function (request) {
  // 对象类型
  let result = [{
    id: '1',
    objectName: '华润海中国三期',
    objectType: '热力站'
  }, {
    id: '2',
    objectName: '大华锦绣华城',
    objectType: '热力站'
  }, {
    id: '3',
    objectName: '大湖山语二期',
    objectType: '热力站'
  }]
  return {
    datas: result
  }
}

const mockRunBenchmarkingAnalisys = function (request) {
  // 对标分析
  let params = JSON.parse(request.body)
  let companys = params.companys
  let columns = [{
    prop: 'indexName',
    label: '指标名称'
  }]
  let iCount = companys.length
  for (let i = 0; i < iCount; i++) {
    columns.push({
      prop: companys[i].id,
      label: companys[i].objectName
    })
  }
  let indexs = params.indexs
  let datas = []
  for (let i = 0, count = indexs.length; i < count; i++) {
    let d = {}
    d.indexName = indexs[i].indexName
    for (let j = 0; j < iCount; j++) {
      d[companys[j].id] = Random.integer()
    }
    datas.push(d)
  }
  let result = {
    columns: columns,
    datas: datas
  }
  return {
    datas: result
  }
}

// const mockMenuTree = function (request) {
//   // 对标分析
//   let result = [
//     {
//       id: 'analysis',
//       code: 'analysis',
//       name: '专家分析',
//       iconCls: 'fa fa-align-justify'
//     },
//     {
//       id: 'intelligent-analysis',
//       code: 'intelligent-analysis',
//       name: '智能分析',
//       'path': '/intelligent-analysis',
//       iconCls: 'fa fa-align-justify',
//       parentId: 'analysis'
//     },
//     {
//       id: 'benchmarking-analysis',
//       code: 'benchmarking-analysis',
//       name: '对标分析',
//       'path': '/benchmarking-analysis',
//       iconCls: 'fa fa-align-justify',
//       parentId: 'analysis'
//     },
//     {
//       id: 'linear-analysis',
//       code: 'linear-analysis',
//       name: '线性分析',
//       'path': '/linear-analysis',
//       iconCls: 'fa fa-align-justify',
//       parentId: 'analysis'
//     },
//     {
//       id: 'analysis-data',
//       code: 'analysis-data',
//       name: '分析数据',
//       'path': '/analysis-data',
//       iconCls: 'fa fa-align-justify',
//       parentId: 'analysis'
//     },
//     {
//       id: 'machine-learning',
//       code: 'machine-learning',
//       name: '机器学习',
//       'path': '/machine-learning',
//       iconCls: 'fa fa-align-justify',
//       parentId: 'analysis'
//     },
//     {
//       id: 'program-management',
//       code: 'program-management',
//       name: '方案管理',
//       'path': '/program-management',
//       iconCls: 'fa fa-align-justify',
//       parentId: 'analysis'
//     },
//     {
//       id: 'analysis-of-object-type-management',
//       code: 'analysis-of-object-type-management',
//       name: '分析对象类型管理',
//       'path': '/analysis-of-object-type-management',
//       iconCls: 'fa fa-align-justify',
//       parentId: 'analysis'
//     },
//     {
//       id: 'analysis-obj',
//       code: 'analysis-obj',
//       name: '分析对象管理',
//       'path': '/analysis-obj',
//       iconCls: 'fa fa-align-justify',
//       parentId: 'analysis'
//     },
//     {
//       id: '2',
//       code: '2',
//       name: '指标类型管理',
//       'path': '/2',
//       iconCls: 'fa fa-align-justify',
//       parentId: 'analysis'
//     },
//     {
//       id: 'index-management',
//       code: 'index-management',
//       name: '指标管理',
//       'path': '/index-management',
//       iconCls: 'fa fa-align-justify',
//       parentId: 'analysis'
//     },
//     {
//       id: '3',
//       code: '3',
//       name: '算法实验室',
//       'path': '/3',
//       iconCls: 'fa fa-align-justify',
//       parentId: 'analysis'
//     },
//     {
//       id: 'DEMO',
//       code: 'DEMO',
//       name: 'DEMO',
//       // 'path': '/program-management',
//       iconCls: 'fa fa-align-justify'
//     },
//     {
//       id: 'axios-demo',
//       code: 'axios-demo',
//       name: 'AXIOS-DEMO',
//       'path': '/axios-demo',
//       iconCls: 'fa fa-align-justify',
//       parentId: 'DEMO'
//     },
//     {
//       id: 'form-input-val',
//       code: 'form-input-val',
//       name: 'FORM-INPUT-VAL',
//       'path': '/form-input-val',
//       iconCls: 'fa fa-align-justify',
//       parentId: 'DEMO'
//     },
//     {
//       id: 'form',
//       code: 'form',
//       name: 'FORM',
//       'path': '/form',
//       iconCls: 'fa fa-align-justify',
//       parentId: 'DEMO'
//     },
//     {
//       id: 'menu1',
//       code: 'menu1',
//       name: 'MENU1',
//       // 'path': '/menu1',
//       iconCls: 'fa fa-align-justify'
//     },
//     {
//       id: 'menu2-1',
//       code: 'menu2-1',
//       name: 'MENU2-1',
//       // 'path': '/menu2-1',
//       iconCls: 'fa fa-align-justify',
//       parentId: 'menu1'
//     },
//     {
//       id: 'menu3-1',
//       code: 'menu3-1',
//       name: 'MENU3',
//       'path': '/menu3-1',
//       iconCls: 'fa fa-align-justify',
//       parentId: 'menu2-1'
//     },
//     {
//       id: 'menu2-2',
//       code: 'menu2-2',
//       name: 'MENU2-2',
//       // 'path': '/menu2-2',
//       iconCls: 'fa fa-align-justify',
//       parentId: 'menu1'
//     },
//     {
//       id: 'menu3',
//       code: 'menu3',
//       name: 'MENU3',
//       'path': '/menu3',
//       iconCls: 'fa fa-align-justify',
//       parentId: 'menu2-2'
//     },
//     {
//       id: 'system-management',
//       code: 'system-management',
//       name: '系统管理',
//       iconCls: 'fa fa-align-justify'
//     },
//     {
//       id: 'function-list',
//       code: 'function-lists',
//       name: '功能菜单管理',
//       'path': '/function-list',
//       iconCls: 'fa fa-align-justify',
//       parentId: 'system-management'
//     }
//   ]
//   return {
//     datas: result
//   }
// }

// const mockUserLogin = function (request) {
//   let params = JSON.parse(request.body)
//   // 用户登录
//   let result = {
//     loginName: params.loginName,
//     nickname: '管理员'
//   }
//   return {
//     datas: result
//   }
// }

// Mock.mock( url, post/get , 返回的数据)；

Mock.mock(global.serverPathScsDI + global.url.parameters.getFunctionTree, 'get', mockFunctionTree)
Mock.mock(global.serverPathScsDI + global.url.parameters.getIndexsTree, 'get', mockIndexTree)
Mock.mock(global.serverPathScsDI + global.url.parameters.runIntelligentAnalisys, 'post', mockRunIntelligentAnalysis)
Mock.mock(global.serverPathScsDI + global.url.parameters.getTasks, 'get', mockTaskList)
Mock.mock(global.serverPathScsDI + global.url.parameters.getObjectType, 'get', mockObjectTypeList)
Mock.mock(global.serverPathScsDI + global.url.parameters.getCompanyTable, 'get', mockCompanyTable)
Mock.mock(global.serverPathScsDI + global.url.parameters.runBenchmarkingAnalisys, 'post', mockRunBenchmarkingAnalisys)
// Mock.mock(global.serverPathScsDI + global.url.menu.getMenuTree, 'get', mockMenuTree)
// Mock.mock(global.serverPathUser + global.url.user.userLogin, 'get', mockUserLogin)
